from .article import JournalArticle
from .book import Book
from .thesis import Thesis

