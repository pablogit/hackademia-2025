# hackademia-2025
Repo pour le projet RefCheck de HackademIA 2025

## Librairies utiles

* pyPDF
* scholarly 

